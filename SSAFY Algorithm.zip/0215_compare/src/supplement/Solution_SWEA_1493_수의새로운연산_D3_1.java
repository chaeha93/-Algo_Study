package supplement;

import java.util.Scanner;

/** 풀어주셨는데 틀림*/

public class Solution_SWEA_1493_수의새로운연산_D3_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for (int tc = 1; tc <= T; tc++) {
			int p = sc.nextInt();
			int q = sc.nextInt();
			int k = 0, x = 0, y = 0, z = 0, w = 0;
			loop: for (int i = 1, l = 1; i <= 10000; l += i, i++) { // i : y축, l : 시작번호(1, 2, 4, 7, ...)
				k = l;
				for (int j = 1, m = i + 1; j <= 10000; m++, j++) { // j : x축, m : 증가량
					if (k == p) { // &(p) = (x, y) = (j, i)
						x = j;
						y = i;
						p = 0;
					}
					if (k == q) { // &(q) = (z, w) = (j, i)
						z = j;
						w = i;
						q = 0;
					}
					if (p + q == 0)
						break loop;
					if (k > p && k < q)
						break;
					k += m;
				}
			}
			p = x + z;
			q = y + w;
			for (int i = 1, l = 1; i <= q; l += i, i++) { // i : y축, l : 시작번호 (1, 2, 4, 7, ...)
				k = l;
				for (int j = 1, m = i + 1; j <= p; m++, j++) { // j : x축, m : 증가량
					k += m;
					if(j==p) k-=m;
				}
			}
			System.out.println("#" + tc + " " + k);
		}
		sc.close();
	}
}
