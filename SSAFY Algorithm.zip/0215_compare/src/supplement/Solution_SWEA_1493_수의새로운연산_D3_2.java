package supplement;

import java.util.Scanner;

public class Solution_SWEA_1493_수의새로운연산_D3_2 {

	static int sharp(int x, int y) { // #(2, 2) = 5, #(3, 1) = 6
		return 1+((x+y) * (x+y-1)/2) - y;
	}
	
	static int[] amp(int n) {
		int s = 0, sh = 0;
		for(s=2; s<=20000; s++) {
			sh = sharp(s-1, 1);
			if(n<=sh) break;
		}
		int y = sh-n+1;
		int x = s-y;
		return new int[] { x, y };
	}

	static int star(int p, int q) {
		int[] pa = amp(p); // &(5) -> {2,2}
		int[] qa = amp(q); // &(6) -> {3,1}
		return sharp(pa[0] + qa[0], pa[1] + qa[1]);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for (int tc = 1; tc <= T; tc++) {
			int p = sc.nextInt();
			int q = sc.nextInt();
			System.out.println("#" + tc + " " + star(p, q));
		}
	}
}
