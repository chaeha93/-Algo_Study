package com.ssafy.exhaustive;

import java.util.Arrays;
import java.util.Scanner;

public class Test {
	
	static int[] numbers;
	
	public static void main(String[] args) {
		int n;
	}
	
}
