package algo0203;

import javax.swing.plaf.synth.SynthSpinnerUI;

public class 재귀함수 {
	public static void main(String[] args) {
		for (int i = 0; i < 5; i++) {
			System.out.print(i + " ");
		}
		System.out.println();
		f1(0);
//		2 4 6 8 10
		for (int i = 2; i <= 12; i += 2) {
			System.out.print(i + " ");
		}
		System.out.println();
		f2(2);

		// 반복문에서 종료 조건이 참이면 무한 반복, CPU만 점유
//		for(int i=0; ;i++) {
//			System.out.println(i);
//		}
//		f3(0);
		for (int testCase = 1; testCase <= 10; testCase++) {
			int sum = 0;
			for (int i = 1; i <= 10; i++) {
				sum += i;
			}
			System.out.println("for : " + sum);
			total = 0;
			f4(1);
			
			System.out.println("재귀함수 합 : " + f5(10));
//							       f5(i) = f5(i-1) + i;
//			1+2+3+4+5+6+7+8+9+10 : f5(10) = f5(9) + 10
//			1+2+3+4+5+6+7+8+9    : f5(9) = f5(8) + 9
//			..
//			1 					 : f5(1) = 1

		tot = 0;
		g(1, 0); //index, 지금까지 더한 합
		System.out.println(tot);
		
//		     반복문  vs 재귀함수
// 무한루프    cpu 점유   StackOverflowError
// 실행시간    빠르다         느리다  "같은 구조라면"	
// n값 변경   변경 어려움   변경 쉽다		
// 가지치기   쉽지 않은	     쉽다	
		
		} //end of for testCase
	} // end of main
	static int tot = 0;
	/** i : index, sum : 지금까지 더한 합*/
	public static void g(int i, int sum) {
		if(i == 11) { //종료파트
			tot = sum;
			return;
		}
		g(i+1, sum+i);
	}
	
	public static int f5(int i) {
		if(i==1) { //종료파트
			return 1;
		}else {//재귀파트
			return f5(i-1) + i;
		}
	}

	static int total = 0;
	public static void f4(int i) {
		if (i > 10) { // 종료 파트
			System.out.println("재귀 : " +total);
			return;
		} else { // 재귀파트
			total += i;
			f4(i + 1);
		}
	}

	public static void f3(int i) {
		double d1 = 3.14;
		System.out.println(i);
		f3(i + 1);

	}

	// 재귀함수
	public static void f1(int i) {
		if (i >= 5) { // 종료파트
			System.out.println();
			return;
		} else { // 반복파트
			System.out.print(i + " ");
			f1(i + 1);
		}
	}

	public static void f2(int i) {
		if (i >= 12) {
			System.out.println();
			return;
		}
		System.out.print(i + " ");
		f2(i + 2);
	}

} // end of class
