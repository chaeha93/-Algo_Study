package supplement;

import java.util.Scanner;

public class Main_정올_1733_오목 {

	static int[] di = { -1, 0, 1, 1 }; // 우상, 우, 우하, 하
	static int[] dj = { 1, 1, 1, 0 };

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		int[][] om = new int[19][19];
		for (int i = 0; i < 19; i++) {
			for (int j = 0; j < 19; j++) {
				om[i][j] = sc.nextInt();
			}
		}
		int ans = 0, ani = 0, anj = 0;
		end: for (int i = 0; i < 19; i++) {
			for (int j = 0; j < 19; j++) {
				if (om[i][j] != 0) {
					for (int d = 0; d < 4; d++) {
						int ni = i + di[d];
						int nj = j + dj[d];
						if (!(0 <= ni && ni < 19 && 0 <= nj && nj < 19 && om[ni][nj] == om[i][j]))
							continue;

						int pi = i - di[d];
						int pj = j - dj[d];
						if (0 <= pi && pi < 19 && 0 <= pj && pj < 19 && om[pi][pj] == om[i][j])
							continue; // 육목

						int cnt = 1;
						while (0 <= ni && ni < 19 && 0 <= nj && nj < 19 && om[ni][nj] == om[i][j] && cnt <= 5) {
							cnt++;
							ni += di[d];
							nj += dj[d];
						}
						if (cnt == 5) {
							ans = om[i][j];
							ani = i + 1;
							anj = j + 1;
							break end;
						}
					}
				}
			}
		}
		System.out.println(ans);
		if (ans != 0)
			System.out.println(ani + " " + anj);
		sc.close();
	}
}
