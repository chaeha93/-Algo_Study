package algo0219;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class 순열 {

	private static int N;
	private static int[] w;

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine()); // 1 <= N <= 9
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");
		w = new int[N]; // 무게, 1 <= w <= 999
		for (int i = 0; i < w.length; i++) {
			w[i] = Integer.parseInt(st.nextToken());
		}
		perm(0);
	}

	/** swap해서 만드는 순열
	 * step : 현재 골라줄 숫자를 넣을 칸
	 * 0 ~ step-1 위치까지는 이미 선택한 숫자, step~끝 : 아직 선택안한 숫자*/
	public static void perm(int step) {
		if(step==N) {
			System.out.println(Arrays.toString(w));
		}
		for(int i=step; i<w.length; i++) {
			swap(step, i);
			perm(step+1);
			swap(step, i); // 원복
		}
	}

	private static void swap(int step, int i) {
		int temp = w[step];
		w[step] = w[i];
		w[i] = temp;
	}
}
