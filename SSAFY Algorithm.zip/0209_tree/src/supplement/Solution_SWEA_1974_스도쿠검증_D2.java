package supplement;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Solution_SWEA_1974_스도쿠검증_D2 {

	static Set<Integer> s = new HashSet<Integer>();
	static int[][] a = new int[9][9];

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for (int tc = 1; tc <= T; tc++) {
			for (int i = 0; i < 9; i++) {
				for (int j = 0; j < 9; j++) {
					a[i][j] = sc.nextInt();
				}
			}
			System.out.println("#" + tc + " " + valid());
		}
		sc.close();
	}

	static int valid() {
		for(int i=0; i<9; i++) {
			s.clear();
			for(int j=0; j<9; j++) {
				s.add(a[i][j]);
			}
			if(s.size()<9) return 0;
		}
		
		for(int i=0; i<9; i++) {
			s.clear();
			for(int j=0; j<9; j++) {
				s.add(a[j][i]);
			}
			if(s.size()<9) return 0;
		}
		
		
		for(int i=0; i<3; i++) {
			for(int j=0; j<3; j++) {
			s.clear();
				for(int k=0; k<3; k++) {
					for(int l=0; l<3; l++) {
						s.add( a[3*i+k][3*j+l]);
					}
				}
				if(s.size()<9) return 0;
			}
		}
		return 1;
	}
}
