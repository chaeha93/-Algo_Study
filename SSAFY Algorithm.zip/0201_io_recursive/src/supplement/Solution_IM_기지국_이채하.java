package supplement;

import java.util.Scanner;

public class Solution_IM_기지국_이채하 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for(int tc = 1; tc<=T; tc++) {
			int N = sc.nextInt();
			char[][] arr = new char[N][N];
			for(int i=0; i<N; i++) {
				String s = sc.next();
				for(int j=0; j<N; j++) {
					arr[i][j] = s.charAt(j);
				}
			}
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					if(arr[i][j] == 'A') {
						if(i-1>=0) {
							arr[i-1][j] = 'X';
						}
						if(i+1<N) {
							arr[i+1][j] = 'X';
						}
						if(j+1<N) {
							arr[i][j+1] = 'X';
						}
						if(j-1>=0) {
							arr[i][j-1] = 'X';
						}
					}
					if(arr[i][j] == 'B') {
						if(i-2>=0) {
							arr[i-2][j] = 'X';
						}
						if(i+2<N) {
							arr[i+2][j] = 'X';
						}
						if(j+2<N) {
							arr[i][j+2] = 'X';
						}
						if(j-2>=0) {
							arr[i][j-2] = 'X';
						}
						if(i-1>=0) {
							arr[i-1][j] = 'X';
						}
						if(i+1<N) {
							arr[i+1][j] = 'X';
						}
						if(j+1<N) {
							arr[i][j+1] = 'X';
						}
						if(j-1>=0) {
							arr[i][j-1] = 'X';
						}
					}
					if(arr[i][j] == 'C') {
						if(i-3>=0) {
							arr[i-3][j] = 'X';
						}
						if(i+3<N) {
							arr[i+3][j] = 'X';
						}
						if(j+3<N) {
							arr[i][j+3] = 'X';
						}
						if(j-3>=0) {
							arr[i][j-3] = 'X';
						}
						if(i-2>=0) {
							arr[i-2][j] = 'X';
						}
						if(i+2<N) {
							arr[i+2][j] = 'X';
						}
						if(j+2<N) {
							arr[i][j+2] = 'X';
						}
						if(j-2>=0) {
							arr[i][j-2] = 'X';
						}
						if(i-1>=0) {
							arr[i-1][j] = 'X';
						}
						if(i+1<N) {
							arr[i+1][j] = 'X';
						}
						if(j+1<N) {
							arr[i][j+1] = 'X';
						}
						if(j-1>=0) {
							arr[i][j-1] = 'X';
						}
					}
					
				}
			}
			int count = 0;
			for(int k = 0; k<N; k++) {
				for(int j=0; j<N; j++) {
					if(arr[k][j] == 'H')
						count++;
				}
			}
			System.out.println("#" + tc + " " + count);
		}	
	}
}
