package supplement;

public class Array4Test {
	public static void main(String[] args) {
		int[] di= {-1, 0, 1, 0};
		int[] dj = {0, 1, 0, -1};
		
		int[][] a = {
				{1,2,3},
				{4,5,6},
				{7,8,9}
		};
		int N = a.length;
		int M = a[0].length;
		for (int i=0; i<a.length; i++) {
			for(int j=0; j<a.length; j++) {
				if(a[i][j] == 5) {
					for(int d=0; d<4; d++) {
						int ni = i+di[d];
						int nj = j + dj[d];
						if(0 <= ni && ni < N && 0 < nj && nj < M) {
							System.out.print(a[ni][nj]);
						}
					}
					System.out.println();
				}
			}
		}
	}
}
