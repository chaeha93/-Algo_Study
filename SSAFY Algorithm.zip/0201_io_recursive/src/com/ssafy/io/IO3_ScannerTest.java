package com.ssafy.io;

import java.util.Scanner;

public class IO3_ScannerTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("가수 : " + sc.nextInt());
		System.out.println("이름 : " + sc.next());
		sc.nextLine(); //버림
		System.out.println("이름 : " + sc.nextLine());
	}
}
